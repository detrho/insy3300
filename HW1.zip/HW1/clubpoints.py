#Dennis Ho

bookPurchase = int(input("How many books did you buy this month? "))


if bookPurchase == 0:
    print("Congratulations, you've earned 0 points so far!")
    
if bookPurchase == 2:
    print("Congratulations, you've earned 5 points so far!")

if bookPurchase == 4:
    print("Congratulations, you've earned 15 points so far!")

if bookPurchase == 6:
    print("Congratulations, you've earned 30 points so far!")

if bookPurchase == 8:
    print("Congratulations, you've earned 60 points so far!")






